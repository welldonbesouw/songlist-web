package com.unseensonglist.songlist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SonglistApplicationTests {

	@Test
	void contextLoads() {
	}

}
