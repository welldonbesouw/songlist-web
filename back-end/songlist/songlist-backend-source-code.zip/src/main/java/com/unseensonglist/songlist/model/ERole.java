package com.unseensonglist.songlist.model;

public enum ERole {
	ROLE_ADMIN,
	ROLE_USER
}
